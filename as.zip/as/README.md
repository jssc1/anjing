[TΣΔM SLΔCҜβΩT] Anda diundang untuk bergabung dengan sebuah Square LINE. 
https://line.me/ti/g2/LMAIQCF1K0

# Saling Berbagi Ilmu
# Mastah Jangan Pelit
